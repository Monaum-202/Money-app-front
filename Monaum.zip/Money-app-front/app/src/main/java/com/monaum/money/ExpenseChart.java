package com.monaum.money;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.data.Entry;
import com.monaum.money.dbUtill.Database;
import com.monaum.money.entity.AddExpence1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpenseChart extends AppCompatActivity {

    PieChart pieChart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_expense_chart);



        pieChart = findViewById(R.id.piChart);
        setupPieChart();

        // Fetch and display expenses
        List<AddExpence1> expenses = getExpenses(); // Fetch expenses from DB
        Map<String, Float> categoryTotals = calculateCategoryTotals(expenses);
        addDataSet();
    }

    private void setupPieChart() {
        pieChart.setRotationEnabled(true);
        pieChart.setHoleRadius(25f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText("Expense Chart");
        pieChart.setCenterTextSize(10);
        pieChart.setDrawEntryLabels(true);
    }

    private Map<String, Float> calculateCategoryTotals(List<AddExpence1> expenses) {
        Map<String, Float> categoryTotals = new HashMap<>();

        for (AddExpence1 expense : expenses) {
            String category = expense.getCategory();
            float amount = expense.getAmount().floatValue();

            if (categoryTotals.containsKey(category)) {
                categoryTotals.put(category, categoryTotals.get(category) + amount);
            } else {
                categoryTotals.put(category, amount);
            }
        }
        return categoryTotals;
    }

    private void addDataSet() {
        List<AddExpence1> expenses = new Database(this).getAllExpence();

        // Map to store category-wise total expenses
        Map<String, Float> categoryExpenseMap = new HashMap<>();

        for (AddExpence1 expense : expenses) {
            String category = expense.getCategory();
            float amount = expense.getAmount().floatValue();

            // Add to existing category total or start a new one
            categoryExpenseMap.put(category, categoryExpenseMap.getOrDefault(category, 0f) + amount);
        }

        ArrayList<PieEntry> yEntries = new ArrayList<>();
        for (Map.Entry<String, Float> entry : categoryExpenseMap.entrySet()) {
            yEntries.add(new PieEntry(entry.getValue(), entry.getKey())); // Amount & Category
        }

        PieDataSet pieDataSet = new PieDataSet(yEntries, "Expenses by Category");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);
        pieDataSet.setValueTextColor(Color.WHITE);

        // Adding Colors
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.BLUE);
        colors.add(Color.GREEN);
        colors.add(Color.RED);
        colors.add(Color.BLACK);
        colors.add(Color.CYAN);
        colors.add(Color.MAGENTA);
        colors.add(Color.DKGRAY);
        colors.add(Color.LTGRAY);
        pieDataSet.setColors(colors);

        PieData pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieChart.invalidate(); // Refresh chart
    }


    private List<AddExpence1> getExpenses() {
        List<AddExpence1> expensesList = new ArrayList<>();

        SQLiteDatabase db = new Database(this).getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM expence", null); // Assuming table name is 'expenses'

        if (cursor.moveToFirst()) {
            do {
                AddExpence1 expense = new AddExpence1();
                expense.setId(cursor.getLong(cursor.getColumnIndexOrThrow("id")));
                expense.setAmount(cursor.getDouble(cursor.getColumnIndexOrThrow("amount")));
                expense.setCategory(cursor.getString(cursor.getColumnIndexOrThrow("category")));
                expense.setWallet(cursor.getString(cursor.getColumnIndexOrThrow("wallet")));
                expense.setNotes(cursor.getString(cursor.getColumnIndexOrThrow("notes")));
                expense.setDate(cursor.getString(cursor.getColumnIndexOrThrow("date")));
                expense.setTime(cursor.getString(cursor.getColumnIndexOrThrow("time")));

                expensesList.add(expense);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return expensesList;
    }

}