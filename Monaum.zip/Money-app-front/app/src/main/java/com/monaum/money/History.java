package com.monaum.money;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.monaum.money.adapters.HistoryAdapter;
import com.monaum.money.adapters.UserAdapter;
import com.monaum.money.databinding.ActivityHistoryBinding;
import com.monaum.money.databinding.ActivityShowListBinding;
import com.monaum.money.dbUtill.Database;
import com.monaum.money.entity.AddIncome1;
import com.monaum.money.entity.Users;

import java.util.ArrayList;

public class History extends  AppCompatActivity {

    ActivityHistoryBinding binding;

    ArrayList<AddIncome1> dataArrayList = new ArrayList<>();
    HistoryAdapter listAdapter ;
    Users listData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

//        setContentView(R.layout.activity_main);
        binding = ActivityHistoryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Database db = new Database(getApplicationContext());
        dataArrayList= (ArrayList<AddIncome1>) db.getAllIncome();

        listAdapter = new HistoryAdapter(History.this, dataArrayList);
        binding.listview.setAdapter(listAdapter);
//        binding.listview.setClickable(true);
//        binding.listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//
//                Toast.makeText(ShowList.this, dataArrayList.get(i).toString(), Toast.LENGTH_LONG).show();
//
////                Intent intent = new Intent(MainActivity.this, Detailed.class);
////                intent.putExtra("name", nameList[i]);
////                intent.putExtra("time", timeList[i]);
////                intent.putExtra("ingredients", ingredientList[i]);
////                intent.putExtra("desc", descList[i]);
////                intent.putExtra("image", imageList[i]);
////                startActivity(intent);
//            }
//        });
    }
}