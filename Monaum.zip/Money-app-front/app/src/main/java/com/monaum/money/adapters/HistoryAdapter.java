package com.monaum.money.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.monaum.money.R;
import com.monaum.money.Signup;
import com.monaum.money.dbUtill.Database;
import com.monaum.money.entity.AddIncome1;

import java.util.ArrayList;

public class HistoryAdapter extends ArrayAdapter<AddIncome1> {

    TextView delete, edit;
    public HistoryAdapter(@NonNull Context context, ArrayList<AddIncome1> dataArrayList) {
        super(context, R.layout.list_item, dataArrayList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {
        AddIncome1 listData = getItem(position);
        if (view == null){
            view = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }


        TextView listTime = view.findViewById(R.id.time);
        TextView listAmount = view.findViewById(R.id.amount);
        TextView listCategory = view.findViewById(R.id.category);
        TextView listWallet = view.findViewById(R.id.wallet);


        listTime.setText(listData != null ? listData.time : "");
//        listAmount.setText(listData != null ? listData.amount : "");
        listCategory.setText(listData != null ? listData.category : "");
        listWallet.setText(listData != null ? listData.wallet : "");

        Database db = new Database(getContext());





        return view;
    }

}
